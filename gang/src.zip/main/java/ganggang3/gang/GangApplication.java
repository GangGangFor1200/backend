package ganggang3.gang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GangApplication {

    public static void main(String[] args) {
        SpringApplication.run(GangApplication.class, args);
    }

}
