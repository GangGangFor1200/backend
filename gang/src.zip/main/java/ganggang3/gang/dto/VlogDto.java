package ganggang3.gang.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class VlogDto {
    private String name;
    private String url;
}

