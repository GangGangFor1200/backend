package ganggang3.gang.Api;

import org.junit.jupiter.api.Test;

public class CourseApiController {
    @Test
    public void findAllMyCourse(){
        //given

        //when

        //then
    }

    @Test
    //course save버튼
    public void updateCourse(){
        //given

        //when

        //then
    }

    @Test
    public void addCourseToMember(){
        //given

        //when

        //then
    }
    @Test
    public void deleteCourseFromMember(){
        //given

        //when

        //then
    }
}
