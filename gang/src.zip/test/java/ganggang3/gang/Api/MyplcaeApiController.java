package ganggang3.gang.Api;

import org.junit.jupiter.api.Test;

public class MyplcaeApiController {

    @Test
    public void findAllMyplace(){
        //given

        //when

        //then
    }

    @Test
    public void addMyplace(){
        //given

        //when

        //then
    }
    @Test
    public void deleteMyplace(){
        //given

        //when

        //then
    }

}
