package ganggang3.gang;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GangApplicationTests {

    @Test
    void contextLoads() {
    }

}
